
public class Medic {

	private String nume;
	private int ani;
	private Pacient pac;
	
	public int getAni() {
		return ani;
	}
	public void setAni(int ani) {
		this.ani = ani;
	}
	
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		nume = nume;
	}
	public Pacient getPac() {
		return pac;
	}
	public void setPac(Pacient pac) {
		this.pac = pac;
	}
	
	
	
}
