
public class Pacient {

	private String nume;
	private String oras;
	private String caz;
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	public String getOras() {
		return oras;
	}
	public void setOras(String oras) {
		this.oras = oras;
	}
	public String getCaz() {
		return caz;
	}
	public void setCaz(String caz) {
		this.caz = caz;
	}
	
	
}
