
public class Sectie {

	private String nume;
	private String spital;
	private Medic medic;
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	public String getSpital() {
		return spital;
	}
	public void setSpital(String spital) {
		this.spital = spital;
	}
	
	
	
	
}
