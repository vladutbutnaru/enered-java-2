
public class Spital {

	
	private String nume;
	private String oras;
	private Pacient p;
	private Medic m;
	
	public Medic getM() {
		return m;
	}
	public void setM(Medic m) {
		this.m = m;
	}
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	public String getOras() {
		return oras;
	}
	public void setOras(String oras) {
		this.oras = oras;
	}
	
	
	
	
	
	 public Pacient getP() {
		return p;
	}
	public void setP(Pacient p) {
		this.p = p;
	}
	
	/* icisa e buba.. nu stiu ce sa fac boss :/
		adica vreau sa apelez medicii din clasa lor si pacientii lor
	*numai ca, numai ca nu realizez cum ar trebui sa fac chemarea
	*am incercat in fel ii chip... ori gresesc metoda de a scrie/citi
	*datele introduse de mine....
	*am incercat cu void string...
	*ma gandesc la o metoda prin care sa apeleze m.Medic.getnume, e posibil?
	*
	*
	*/
	
	public void afiseaza (Medic m){
	
		
		 System.out.println( m.getNume()+" are atribuiti urmatorii pacienti: "+ m.getPac());
		
	
	
}}
