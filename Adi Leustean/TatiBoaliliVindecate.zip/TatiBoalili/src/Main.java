
public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

      		Pacient Gigel=new Pacient();
		Gigel.setNume(" Gigel ");
		Gigel.setOras(" Iasi ");
		Gigel.setCaz(" Bronsita ");
		
		Pacient Dorel= new Pacient();
		Dorel.setNume(" Dorel ");
		Dorel.setOras(" Bacau ");
		Dorel.setCaz(" 3 maini ");
		
		Pacient Fane= new Pacient();
		Fane.setNume(" Fane zidaru ");
		Fane.setOras(" Vaslui ");
		Fane.setCaz(" Mana rupta ");
		
		Medic Lobu = new Medic();
		Lobu.setAni(7);
		Lobu.setNume(" Lobinschi ");
		Lobu.setPac(Fane);
		
		Medic Ilz= new Medic();
		Ilz.setNume(" Ilzinschi ");
		Ilz.setAni(3);
		Ilz.setPac(Dorel);
		
		Medic Sco = new Medic();
		Sco.setAni(10);
		Sco.setNume(" Scorbinsky ");
		Sco.setPac(Gigel);
		
		
		
		Sectie cardiologie = new Sectie();
		cardiologie.setMedic(Sco);
		
		Sectie neuro=new Sectie();
		neuro.setMedic(Lobu);
		
		
		Spital Galata= new Spital();
		Galata.afiseaza(cardiologie);
		Galata.afiseaza(neuro);
		
	
	
	
	
	
	
	}

}
