
public class Spital {

	
	private String nume;
	private String oras;

	private Sectie m;
	
	public Sectie getM() {
		return m;
	}
	public void setM(Sectie m) {
		this.m = m;
	}
	public String getNume() {
		return nume;
	}
	public void setNume(String nume) {
		this.nume = nume;
	}
	public String getOras() {
		return oras;
	}
	public void setOras(String oras) {
		this.oras = oras;
	}
	
	
	
	
	
	
	
	/* icisa e buba.. nu stiu ce sa fac boss :/
		adica vreau sa apelez medicii din clasa lor si pacientii lor
	*numai ca, numai ca nu realizez cum ar trebui sa fac chemarea
	*am incercat in fel ii chip... ori gresesc metoda de a scrie/citi
	*datele introduse de mine....
	*am incercat cu void string...
	*ma gandesc la o metoda prin care sa apeleze m.Medic.getnume, e posibil?
	*
	*
	*/
	
	public void afiseaza (Sectie m){
	
		
		 System.out.println( m.getMedic().getNume()+" are atribuiti urmatorii pacienti: "+ m.getMedic().getPac().getNume() + ", ce sufera de "+m.getMedic().getPac().getCaz());
		
	
	
}}
