
public class Account {
	private String id;
	private String name;
	private int balance;
	
	public void setId(String id){
		this.id=id;
		
	}
	public String getId(){
		return id;
		
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	
	public Account(String idP, String nameP ){
		
		id=idP;
		name=nameP;
	}
	
    public Account(String idP, String nameP,int balanceP ){
		
		id=idP;
		name=nameP;
		balance=balanceP;
	}
	
    public int credit(int amount){
    	
    	balance=balance+amount;
    	System.out.println(id + " zice: am primit " + amount + " lei");
    	return balance;
    }
	public int debit(int amount){
		if(amount<=balance){
			balance=balance-amount;
			System.out.println(id + " zice: am cheltuit " + amount + " lei");
		}
		else
			System.out.println(id + " zice: sunt sarac");
		return balance;
		
		
	}
	public int transferTo(Account another,int amount){
		
		if(amount<=balance){
			balance=balance-amount;
			another.credit(amount);
			System.out.println(id + " zice: i-am dat lui " + another.getId()  + " "+ amount + " lei");
			
		}
			else
				System.out.println(id + " zice: sunt sarac");
		return balance;
		
		
		
	}
	
	
	
	

}
