
public class Book {
	
	private String name;
	private Author autor;
	private double price;
	private int qty;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public Author getAutor() {
		return autor;
	}
	public void setAutor(Author autor) {
		this.autor = autor;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQty() {
		return qty;
	}
	public void setQty(int qty) {
		this.qty = qty;
	}
	
	
	public Book(String namej,Author autorj,double pricej,int qtyj){
		name = namej;
		autor = autorj;
		price = pricej;
		qty = qtyj;
		
		
	}
	
	public void afiseaza(){
		System.out.println("Cartea " + name + " este scrisa de " + autor.getName());
	}
	
	

}
