
public class Circle {

	private double radius;
	private String color;

	public double getRadius() {
		return radius;
	}

	public void setRadius(double radius) {
		this.radius = radius;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public Circle() {

	}

	public Circle(double d) {
		radius = d;
	}

	public Circle(double d, String s) {

		radius = d;
		color = s;

	}

	public double ridicaLaPutere(double x, int y) {
		double rezultat = 1;
		for (int numar = 0; numar < y; numar++) {

			rezultat = rezultat * x;

		}
		return rezultat;
	}

	public double getArea() {
		return 3.14 * ridicaLaPutere(radius, 2);
	}

}
