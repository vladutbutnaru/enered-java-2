
public class Date {

	private int day;
	private int month;
	private int year;
	public int getDay() {
		return day;
	}
	public void setDay(int day) {
		this.day = day;
	}
	public int getMonth() {
		return month;
	}
	public void setMonth(int month) {
		this.month = month;
	}
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	
	public Date(int day1, int month1, int year1){
		day = day1;
		month=month1;
		year = year1;
		
		
		
		
	}
	public void setDate(int day1, int month1, int year1){
		day = day1;
		month=month1;
		year = year1;
		
	}
public void afiseaza(){
	System.out.println(day +"/" + month + "/" + year);
	
}
}
