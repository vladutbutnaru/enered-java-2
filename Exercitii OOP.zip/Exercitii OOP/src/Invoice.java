import java.util.ArrayList;

public class Invoice {
	//am lista de InvoiceItem
	
	//cu getter si setter
	
	

	//metoda getTotalPrice() care aduna toate totalurile InvoiceItem-urilor si returneaza rezultatul


ArrayList<InvoiceItem> produse = new ArrayList<InvoiceItem>();

public ArrayList<InvoiceItem> getProduse() {
	return produse;
}

public void setProduse(ArrayList<InvoiceItem> produse) {
	this.produse = produse;
}


public double getTotalPrice(){
	
	
	double sum=0;
	
	for(int i=0;i<produse.size();i++){
		
		sum=sum + produse.get(i).getTotal();
		
		
		
	}
	
	return sum;
}





}
