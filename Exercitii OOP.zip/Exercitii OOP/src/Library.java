import java.util.ArrayList;

public class Library {
//lista de carti
	
	//metoda afiseaza toate cartile si autorii lor asa : nume carte -> autor
	
	ArrayList <Book> carti = new ArrayList <Book>();

	public ArrayList<Book> getCarti() {
		return carti;
	}

	public void setCarti(ArrayList<Book> carti) {
		this.carti = carti;
	}
	public void afiseaza(){
		for(int i = 0; i < carti.size(); i++){
			System.out.println(i + " . " + carti.get(i).getName() + " -> " + carti.get(i).getAutor().getName());
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
