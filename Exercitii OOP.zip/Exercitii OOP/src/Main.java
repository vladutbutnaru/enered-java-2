import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {

		//1.Exercitiul no1.
		
		Circle x = new Circle();
		Circle y= new Circle(2.0);
		Circle z= new Circle(3.0, "Red");
		x.setRadius(5);
		System.out.println(x.getArea());
		System.out.println(y.getArea());
		System.out.println(z.getArea());
		
		// Exercitiul 2
		
		
		Rectangle a = new Rectangle();
		a.setLatime(8.3);
		a.setLungime(10.25);
		Rectangle b = new Rectangle(12.5 , 15.8);
		
		System.out.println(a.getArea() +" " + a.getPerimetru());
		System.out.println(b.getArea() +" " + b.getPerimetru());
		
		// Exercitiul 3
		
		Employee c = new Employee (5,"Diana","Ciocirlan",10000);
		System.out.println(c.getFirstName() + " " + c.getLastName() + " are salariul " + c.raiseSalary(10));
		
		// Exercitiul 4
		
		InvoiceItem ori =new InvoiceItem("cipsuri","lays" , 5, 25.25);
		System.out.println(ori.getTotal());
		
		
		InvoiceItem ori2 =new InvoiceItem("cipsuri","lays" , 7, 30.30);
		
		
		Invoice factura= new Invoice();
	
		
		factura.getProduse().add(ori);
		factura.getProduse().add(ori2);
		System.out.println(factura.getTotalPrice());
		
		//sau
		
		ArrayList<InvoiceItem> cosProduse = new ArrayList<InvoiceItem>();
		cosProduse.add(ori);
		cosProduse.add(ori2);
		factura.setProduse(cosProduse);
		System.out.println(factura.getTotalPrice());
		
		//Exercitiul 5
		
		Account ac=new Account("Vlad","Economie",2908);
		Account portofel=new Account("Tudor","Economie1",39078);
		
		ac.credit(10);
		ac.credit(10);
		ac.credit(10);
		ac.credit(10);
		
		portofel.debit(39079);
		ac.transferTo(portofel, 1);
		portofel.debit(39079);
		
		
		//Exercitziul 6
		
		Date alpha = new Date(1,3,2017);
		
		alpha.afiseaza();
		alpha.setDate(5, 8, 2018);
		alpha.afiseaza();
		
		
		
		//exercitiul 7
		Time beta=new Time(9,8,4);
		while(beta.getSecond() < 59){
			beta.nextSecond();
		
			
		}
		
		
		
		//Ex 8
		
		Author adi= new Author("Adi", "blah blah@gmail.com", 'M');
	adi.afiseaza();
	
	
	
	// Ex 9
	
	Book hhh = new Book("Kamasutra",adi,75,10);
	Book hhh1 = new Book("Ghid practic de lucru manual",adi,75,10);
	Book hhh2 = new Book("Balena Albastra",adi,75,10);
	Book hhh3 = new Book("Pas cu pas",adi,75,10);
	
	hhh.afiseaza();
	
	Library ght = new Library();
	
	ght.getCarti().add(hhh);
	ght.getCarti().add(hhh1);
	ght.getCarti().add(hhh2);
	ght.getCarti().add(hhh3);
	
	
	
	System.out.println(ght.getCarti().get(2).getName());
	
	
}
}