
public class Rectangle {
	
	private double lungime;
	private double latime;
	public double getLungime() {
		return lungime;
	}
	public void setLungime(double lungime) {
		this.lungime = lungime;
	}
	public double getLatime() {
		return latime;
	}
	public void setLatime(double latime) {
		this.latime = latime;
	}
	
	public Rectangle(){
		
	}
	
	
	public Rectangle(double lung, double lat){
		
		lungime = lung;
		latime = lat;
			
		
	}
			
	
	public double getArea(){
	return lungime*latime;	
	}
	
	 public double getPerimetru(){
		 return (lungime+latime)*2;
		 
	 }
	

}
