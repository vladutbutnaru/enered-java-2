
public class Time {
	
	private int hour;
	private int minute;
	private int second;
	public int getHour() {
		return hour;
	}
	public void setHour(int hour) {
		this.hour = hour;
	}
	public int getMinute() {
		return minute;
	}
	public void setMinute(int minute) {
		this.minute = minute;
	}
	public int getSecond() {
		return second;
	}
	public void setSecond(int second) {
		this.second = second;
	}

	public Time ( int hourp, int minutep, int secondp){
		hour=hourp;
		minute=minutep;
		second=secondp;
	}
	
	public void setTime (int hourp ,int minutep, int secondp ){
		hour=hourp;
		minute=minutep;
		second=secondp;
	}
	public Time nextSecond(){
		second=second+1;
		System.out.println(hour  + " : " + minute + " : " + second);
		return  this ;
		
	}
	
	
	
	public Time previousSecond(){
		second=second-1;
		System.out.println(hour  + " : " + minute + " : " + second);
		return  this ;
		
	}
	
}
