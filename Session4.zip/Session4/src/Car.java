
public class Car {

	//proprietati
	//variabile membre
	private String marca;
	private String culoare;
	private double capacitateCilindrica;
	private String nrInmatriculare;
	private int consumMediu;
	private int rezervor;
	
	
	public String getCuloare() {
		return culoare;
	}

	public void setCuloare(String culoare) {
		this.culoare = culoare;
	}

	public String getNrInmatriculare() {
		return nrInmatriculare;
	}

	public void setNrInmatriculare(String nrInmatriculare) {
		this.nrInmatriculare = nrInmatriculare;
	}

	public int getConsumMediu() {
		return consumMediu;
	}

	public void setConsumMediu(int consumMediu) {
		this.consumMediu = consumMediu;
	}

	public int getRezervor() {
		return rezervor;
	}

	public void setRezervor(int rezervor) {
		this.rezervor = rezervor;
	}

	//getter pentru marca
	public String getMarca(){
		return marca;
	}
	
	//setter pentru marca
	void setMarca(String m){
		marca = m;
	}
	
	//getter pentru capacitateCilindrica
	double getCapacitateCilindrica(){
		return capacitateCilindrica;
	}
	
	//setter
	void setCapacitateCilindrica(double c){
		capacitateCilindrica = c;
	}
	
	
	//metoda pentru detalii complete
	void arataDetalii(){
		System.out.println(marca + " " + capacitateCilindrica + " " +
	culoare + " ");
		
	}
	
	void merg(int km){
		//in rezervor am 35 l
		//consum mediu 8%
		//merg km kilometri
		//afisez cat mai am in rezervor
		
		rezervor = rezervor - consumMediu * km / 100;
		
		
	}
	int kmRamasi(){
		return rezervor*100/consumMediu;
	}
	
	
	
}
