
public class Main {

	public static void main(String[] args) {
		
		//instantiere
		Marker markerVerde = new Marker("albastru", "Schneider");
		
		
		
		markerVerde.setColor("rosu"); // markerVerde.color = rosu
		
		System.out.println(markerVerde.getColor());
		
		
		
		markerVerde.write();
		
		//instantiere
		Marker markerAlbastru = new Marker("Albastru", "Schneider");
		
		
		
		markerAlbastru.write();
		
		//instantiere
		Mate clasaMatematica = new Mate();
		
		
		System.out.println(clasaMatematica.plus(5, 6, 8));
		int sum = clasaMatematica.plus(5, 6, 8);
		
		int a = 3;
		int b = 5;
		int c = 7;
		
		System.out.println(clasaMatematica.minus(a,b));
		System.out.println(clasaMatematica.minus(a,c));
		

		if(clasaMatematica.compare(6) == true)
			System.out.println("da");
		else
			System.out.println("nu");
		
		clasaMatematica.ePar(4);
		clasaMatematica.ePar(5);
		
		Student elev = new Student();
		elev.setNume("vlad");
		elev.setNota1(2);
		elev.setNota2(9);
		elev.setNota3(8);
		System.out.println("Elevul cu numele " +
		elev.getNume() + " are media " + elev.medie());
		
		Room cameraVerde = new Room();
		cameraVerde.setName("Camera Verde");
		cameraVerde.setS(elev);
		
		System.out.println(cameraVerde.getS().getNume());
		
		
		
		
		Car bmw = new Car();
		Car seat = new Car();
		bmw.setMarca("BMW");
		seat.setMarca("Seat");
		bmw.setCuloare("Rosu");
		seat.setCuloare("Verde");
		
		seat.setConsumMediu(13);
		bmw.setConsumMediu(15);
		seat.setRezervor(36);
		bmw.setRezervor(60);
		
		
		seat.merg(100);
		bmw.merg(300);
		
		System.out.println(seat.getRezervor());
		System.out.println(bmw.getRezervor());
		System.out.println(seat.kmRamasi());
		System.out.println(bmw.kmRamasi());
		
	}

}
