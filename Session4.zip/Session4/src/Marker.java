
public class Marker {

	Marker(String c, String p){
		color = c;
		producator= p;
	}
	
	
	private String color;
	private String producator;
	
	String getColor(){
		return color;
		
	}
	
	void setColor(String c){
	
		if(c!="verde"){
			System.out.println("Marker-ul nu il poate avea pe rosu ca culoare ");
		} 
		else{
			color=c;
			
		}
		
		
	}
	
	
	
	
	void write(){
		System.out.println("Eu scriu cu " + color);
		System.out.println("Eu scriu cu " +  producator);
		
	}
	
	double getNrPi(){
		return 3.14;
		
	}
	
	
	
}
