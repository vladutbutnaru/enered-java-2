
public class Mate {

	int plus(int a, int b, int c) {

		return a + b + c;

	}

	int minus(int a, int b) {
		return a - b;

	}

	boolean compare(int a) {
		if (a >= 5 && a <= 10)
			return true;
		else
			return false;

	}
	
	void ePar(int a){
		if(a%2==0)
			System.out.println("Da " + a + " este numar par");
		else
			System.out.println("Nu " + a + " nu este par");
		
	}

}
