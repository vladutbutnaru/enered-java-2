
public class Animal {
	 private String nume;
	 private Cal c;
	 private Caine catel;
	 
	
	
	
	public String getNume() {
		return nume;
	}

	public void setNume(String nume) {
		this.nume = nume;
	}
	
	
	
}
