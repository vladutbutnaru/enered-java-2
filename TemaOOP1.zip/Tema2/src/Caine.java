
public class Caine extends Animal implements Callable{
		private int ani ;
		private String rasa;
		
		void cumpara(){
			
			System.out.println("cel mai frumos catel din magazin este " + getNume() + " din rasa "+ getRasa() + " avand numai " + getAni()+ " ani" );
		}
	
	
	
	
	public int getAni() {
			return ani;
		}




		public void setAni(int ani) {
			this.ani = ani;
		}




		public String getRasa() {
			return rasa;
		}




		public void setRasa(String rasa) {
			this.rasa = rasa;
		}




	@Override
	public void call() {
		System.out.println("Catelul " + getNume() + " este chemat cutu cutu " );
		
	}
	
	
	

}
