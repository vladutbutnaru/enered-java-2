
public class Cal extends Animal implements Callable {
		private int viteza;
		private String rasa;
		
		void competite() { 
			System.out.println("Acest cal din rasa" + getRasa() + " a castigat cursa avand o viteza de " + getViteza() + " km pe ora");
		 	
		}
	
	
	public int getViteza() {
			return viteza;
		}




		public void setViteza(int viteza) {
			this.viteza = viteza;
		}




		public String getRasa() {
			return rasa;
		}




		public void setRasa(String rasa) {
			this.rasa = rasa;
		}




	@Override
	public void call() {
			System.out.println("Calutul " + getNume() + " este chemat whiip whiip " );
	}
	
	

}
