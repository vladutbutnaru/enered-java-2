
public interface Callable {
	
	void call();
	

}
