
public class Main {

	public static void main(String[] args) {
		
		Pisica pisi=new Pisica();
		pisi.setNume("Motata");
		pisi.setMancare("Whiskas");
		pisi.setTalie("Talie mare");
		pisi.mananca();
		pisi.call();
		System.out.println(" --------------");
		
		Cal calut=new Cal();
		calut.setNume("Hodor");
		calut.setRasa("Belgiana");
		calut.setViteza(55);
		calut.competite();
		calut.call();
		System.out.println(" --------------");
		
		Caine catel = new Caine();
		catel.setAni(1);
		catel.setNume("Bobita");
		catel.setRasa("Haski");
		catel.cumpara();
		catel.call();
		
		
		
		

	}

}
