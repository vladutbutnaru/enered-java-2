
public class Pisica extends Animal implements Callable{
	  private	String talie;
	  private String mancare;
	  
	  public void mananca(){
		  System.out.println("Pisica " + getNume() +" de talie " + getTalie()  + ", mananca de obicei " + getMancare() );
		  
	  }
	  
	  
	public String getMancare() {
		return mancare;
	}


	public void setMancare(String mancare) {
		this.mancare = mancare;
	}


	public String getTalie() {
		return talie;
	}

	public void setTalie(String talie) {
		this.talie = talie;
	}

	@Override
	public void call() {
		System.out.println(" pisica " + getNume() + " este chemata in felul urmator : pisi pisi ");
		
	}
	  
	
	
	

}
